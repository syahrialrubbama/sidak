<?php
$koneksi = new mysqli("localhost", "root", "", "db_water_teras1");